# BBL upsell

Restarted 2026-11-11 on the new feature set; the old work is in `legacy/` for reference only.

```
upsell/
  notebooks/          open these, in order
  code/
    upsell_core.py    data, folds, Gini, results board
    upsell_select.py  column screening and selection (shuffled-label check, both models)
    upsell_special.py look-alike rate, group-model scores, loan-likeness score (U05)
    upsell_more.py    other model kinds for the blend: DART, ExtraTrees, logistic, neural network (U10)
    upsell_models.py  LightGBM / XGBoost / CatBoost: fit, 5-fold fit, Optuna tuning
    upsell_features.py categorical encodings (and later engineered columns), learned inside each fold
    nb_src/           notebook sources; python make_notebooks.py rebuilds ../notebooks
  legacy/             old U00-U03 (XGBoost only, old feature set)
```

**On the bank machine:** put the notebooks, `upsell_core.py` and `upsell_models.py` in one folder. Put the two input files (bbl_eu_payways_postdecomm_train.parquet, _test.parquet) in
`data/upsell/` next to them. Results go to `runs_upsell_v2/`; the old `runs_upsell/` is not touched.

**How results are judged:** same seed, same 5 customer-grouped folds (saved once, reused).
A change wins when both the training CV Gini and the test Gini go up. Every result is a
row in `runs_upsell_v2/results_upsell.csv`.

| Notebook | What it does |
|---|---|
| `U01_baseline` | Checks the files; population and columns (missing share, single-column Gini); builds the folds; LightGBM and XGBoost with library defaults on all columns (CatBoost left out: too slow) |
| `U02_tune` | Optuna for each model on the training folds (defaults are trial 0); refits the best settings; equal-weight rank blend; verdict vs the best default |
| `U03_categoricals` | 8 ways to handle the 10 categorical columns (codes, frequency, one-hot, out-of-fold target rate, target+frequency, strong-column means, native+target, learned embeddings), each with U02's tuned settings, vs native |
| `U04_features` | Engineered columns in 10 blocks (products, existing loan, transaction trends, 90-day P&L, liabilities, digital, risk, income, segment-relative, strong-column pairs). Block fits are information only; evidence per column (single-column Gini, missing shares, LightGBM gain vs shuffled labels) saved as `column_evidence_upsell.csv` for selection; nothing dropped here |
| `U04b_features` | More of what worked: pairs of the 10 strongest columns, amounts split by has_loan, 90-day totals vs year/liabilities/facility/segment. Every column scored by LightGBM and XGBoost (shuffled-label check); candidate = beats chance in either |
| `U05_special` | Look-alike take-up rate (500 nearest customers), one-group model scores, loan-likeness score, all out-of-fold. Whole pool re-scored by both models; its `column_evidence_upsell.csv` feeds selection |
| `U06_missing_compress` | Missing/zero counts per column group; PCA summaries of big groups. Builds the final pool for fold 0 and saves it (`runs_upsell_v2/pool_upsell/`, ~2 GB per fold); whole pool re-scored by both models; its evidence file feeds U07 |
| `U07_selection` | 7 ways of choosing 60 columns (originals only, shuffled-label signal, signal with near-duplicates pruned, gain, SHAP, single-column Gini, ridge forward selection), each a full 5-fold fit with both models vs U02; pool sets vs originals-only; drift check and swaps on the best set; writes `chosen_columns_upsell.json` |
| `U07b_how_many` | No column cap: sets of 60, 120, originals + 40 new, all candidates, whole pool, fitted with U02's settings vs U02 on 218 columns (and blends); writes the forward set to its own `chosen_columns_upsell.json` |
| `U08_retune` | Retunes LightGBM and XGBoost on shap_top and signal_top (60 columns each, from the saved pool), trial 0 = U02's settings; vs U02 on all 218 columns, plus each set's blend; writes the forward set to `chosen_columns_upsell.json` and its `best_params_<model>_upsell.json` |
| `U08b_retune_how_many` | Separate from U08: retunes LightGBM and XGBoost on U07b's chosen set (trial 0 = U02's settings); vs U02, vs the same set untuned, blend vs U02's blend; own folder and outputs |
| `U09_rows_final_fit` | On `SOURCE`'s columns and settings (U08 by default, or U08b): row options (non-takers 50%/25%, takers x5, per-customer weights) vs all rows; each model keeps its best WIN; then a final fit on the whole training file (full pool saved as `full_*.parquet`), test Gini vs the 5-fold average; saves the final models and `final_setup_upsell.json` |
| `U10_more_models` | On U08's 60 columns: logistic, logistic on PCA inputs, small neural network (sklearn), ExtraTrees, LightGBM DART; each alone vs U08's LightGBM, and added to U08's LightGBM + XGBoost blend vs that blend |
| `U12_dai_file` | Two parquet files for Driverless AI from the whole-file pool (U09's `full_*.parquet`): all 517 columns + label, training file with our `fold` column; column list with sources; judge DAI on test Gini |

Both resume where they stopped: the folds are saved as each one finishes, and the Optuna trials are saved as each one finishes.
